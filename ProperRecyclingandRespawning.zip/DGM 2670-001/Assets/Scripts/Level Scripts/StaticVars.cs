﻿

public class StaticVars {
    public static float distance = 17.5f;
    public static float nextSectionPosition = 52.5f;
}

