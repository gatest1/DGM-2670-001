﻿public class Statics
{

    public static float distance = 4;
    public static float nextPosition = 4;
	
	
}
